# MIND-small E0 + R1-R5 + 3 graph snapshots

Bộ khởi đầu để thực hiện task trong Proposal v2: tải MIND-small, chạy EDA (E0), điền A.2/A.3, dựng quan hệ R1-R5 và 3 đồ thị cơ bản.

## 1. Chọn môi trường

**Khuyên dùng Google Colab** nếu bạn chưa thiết lập Python trên máy. Chưa cần GPU cho EDA và dựng cạnh. Với bộ dữ liệu MIND-small, CPU + RAM là đủ cho giai đoạn này; Louvain trên 3 đồ thị có thể tốn thời gian/RAM, nên có tuỳ chọn bỏ qua để chạy trước.

Bạn cũng có thể chạy local bằng Python 3.10 hoặc 3.11 và VS Code.

## 2. Tải dữ liệu

1. Mở trang chính thức: <https://msnews.github.io/>.
2. Đọc và chấp nhận Microsoft Research License Terms trước khi tải.
3. Tải `MINDsmall_train.zip` và `MINDsmall_dev.zip`.
4. Đặt ZIP vào thư mục `data/`, hoặc giải nén thành:

```text
data/
  MINDsmall_train/
    behaviors.tsv
    news.tsv
    entity_embedding.vec       # không bắt buộc cho R1-R5
    relation_embedding.vec     # không bắt buộc cho R1-R5
  MINDsmall_dev/
    behaviors.tsv
    news.tsv
```

Code cũng có thể tải ZIP từ endpoint chính thức khi chạy `--download` (chỉ dùng sau khi bạn đã chấp nhận điều khoản).

## 3. Chạy trên Windows / VS Code

Mở terminal tại thư mục chứa `run_mind_pipeline.py`:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python run_mind_pipeline.py --data-dir data --output-dir outputs
```

Nếu PowerShell chặn activate, có thể mở terminal CMD và chạy `.venv\Scripts\activate.bat`, hoặc dùng Colab.

Nếu muốn script tự tải dữ liệu (sau khi đã đồng ý điều khoản):

```powershell
python run_mind_pipeline.py --download --data-dir data --output-dir outputs
```

Chạy thử nhanh, bỏ qua Louvain/NMI:

```powershell
python run_mind_pipeline.py --data-dir data --output-dir outputs --skip-community
```

## 4. Chạy trên Google Colab

1. Tải và giải nén ZIP project này, hoặc tải riêng `run_mind_pipeline.py` và `requirements.txt` lên Colab.
2. Tải ZIP MIND-small lên phiên runtime hoặc dùng lệnh sau sau khi đã chấp nhận điều khoản:

```bash
!pip install -r requirements.txt
!python run_mind_pipeline.py --download --data-dir data --output-dir outputs --skip-community
```

3. Khi EDA/graph đã chạy được, chạy lại không có `--skip-community` để bổ sung Louvain modularity và NMI:

```bash
!python run_mind_pipeline.py --data-dir data --output-dir outputs
```

4. Tải thư mục `outputs/` về máy. Colab runtime có thể bị xoá khi phiên kết thúc; hãy tải kết quả hoặc lưu sang Google Drive.

## 5. Output sau khi chạy

- `A2_split_statistics.csv`: 4 dòng Train chọn tham số (09-13/11), Validation (14/11), Train cuối (09-14/11), Test (15/11).
- `A3_daily_eda.csv`: theo ngày 09-15/11; có `# Imp.`, `# Click`, CTR, user, user mới, số tin ứng viên duy nhất, tỷ lệ tin ứng viên chưa từng được click trước bucket.
- `A3_6hour_eda.csv`: bảng theo bucket 6 giờ.
- `dataset_profile.csv`: thống kê tổng train/dev/combined để đối chiếu số liệu trong proposal.
- `history_consistency_summary.csv` và `history_consistency_by_user.csv`: kiểm tra History có thay đổi theo các impression của cùng user không.
- `nodes.csv`: node type, ID, label và category.
- `relations/`: R1, R2, R3 (gồm hai nhánh), R4 và R5 ở dạng CSV.
- `graphs/Ghist_edges.csv`: History + quan hệ nội dung R2/R3/R5.
- `graphs/Ghist_click_0913_edges.csv`: Ghist + click labels train từ 09-13/11.
- `graphs/Ghist_click_0914_edges.csv`: Ghist + click labels train từ 09-14/11.
- `graph_manifest.csv`: mô tả cutoff của từng graph.
- `SNA_graph_summary.csv`: số node/cạnh, mật độ, bậc trung bình, thành phần liên thông, modularity và NMI (nếu Louvain chạy thành công).
- `SNA_degree_distribution.csv`: phân phối bậc theo graph và node type.
- `missing_news_ids.csv`: ID trong history/impressions nhưng không có metadata trong news.tsv đã gộp.

Các CSV `graphs/*_edges.csv` có thể nhập vào Gephi (Data Laboratory → Import Spreadsheet). Cột `src_type`/`dst_type` giữ loại node, `relation` giữ loại cạnh, `weight` giữ trọng số. R5 được lưu một lần cho mỗi cặp thực thể (quan hệ vô hướng); khi chuyển sang thư viện GNN có hướng, hãy thêm cạnh reverse nếu cần.

## 6. Định nghĩa và giả định cần ghi trong báo cáo

- **CTR** trong bảng A.3 được tính là tổng click / tổng candidate occurrences × 100; `# Tin ứng viên` là số `news_id` khác nhau xuất hiện trong impressions ở bucket.
- **% user mới** là tỷ lệ user có lần xuất hiện đầu tiên trong toàn bộ behaviors gộp rơi vào bucket đó.
- **% tin ứng viên chưa từng được click** tính trên tập tin ứng viên duy nhất của bucket; tập đã-click ban đầu được seed từ History của các impression train sớm nhất, sau đó cập nhật bằng click labels ở các ngày/bucket trước đó. Giá trị này nên được đối chiếu với giả định history trước 09/11 trong proposal.
- **R1 clicked** là cạnh user-news có ít nhất một bằng chứng click từ History train seed hoặc positive label của impression train trước cutoff; cạnh được deduplicate để không đếm một click lịch sử lặp lại mỗi lần History xuất hiện.
- **R2 mentions** là news-entity từ entity JSON của title và abstract; nếu cùng entity xuất hiện cả hai nơi, dùng confidence lớn nhất.
- **R3** gồm `news -> subcategory` và `subcategory -> category`. ID subcategory có kèm category để tránh gộp hai subcategory trùng tên thuộc category khác nhau.
- **R4 co-click** là chuyển tiếp news liền kề trong History theo thứ tự và trong chuỗi positive-click impression theo thời gian. Chỉ impression có đúng một positive click được dùng để mở rộng chuỗi R4, vì MIND không cho biết thứ tự click trong cùng một impression có nhiều click. Giữ tối đa 10 neighbor theo từng news, xếp theo trọng số giảm dần.
- **R5 co-occur** là cặp entity cùng xuất hiện trong metadata của một news; trọng số là số news có cặp entity đó.
- Các graph dùng **History seed từ train**, không dùng click labels của dev/test để tạo cạnh. `Ghist_click_0913` thêm click train ngày 09-13/11; `Ghist_click_0914` thêm click train ngày 09-14/11. R2/R3/R5 được dựng từ metadata news của train+dev vì metadata nội dung được xem là có sẵn ở thời điểm hiển thị theo proposal.
- Với SNA, script chiếu graph dị thể về một **đồ thị vô hướng** để tính thành phần liên thông, Louvain modularity và NMI giữa community và category của news. Đây là lựa chọn phân tích; edge CSV vẫn giữ relation gốc.

## 7. Lưu ý khi kiểm tra

- Số ở Bảng A.2/A.3 phải lấy từ kết quả script sau khi chạy trên ZIP chính thức, không điền theo số dự kiến nếu số đếm thực tế khác.
- Theo proposal, Train cuối kỳ vọng khoảng 156,965 impressions / 236,344 clicks; Test khoảng 73,152 impressions / 111,383 clicks. Dùng như **mốc đối chiếu**, không phải số được hard-code.
- Nếu chạy local bị thiếu RAM hoặc Louvain quá lâu, chạy `--skip-community` trước để có EDA + relation files + 3 graph edge files; sau đó chạy lại không có cờ này để tính community metrics.
